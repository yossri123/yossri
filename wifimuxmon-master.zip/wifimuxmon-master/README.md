# wifimuxmon
Wifi Monitor on Termux Project

Install:

git clone https://github.com/kangris-sket/wifimuxmon

chmod +x install.sh

./install.sh
